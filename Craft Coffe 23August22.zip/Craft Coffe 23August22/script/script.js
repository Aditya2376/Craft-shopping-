//js for Header
function openNav() {
  document.getElementById("navSlide").style.width = "300px";
}

function closeNav() {
  document.getElementById("navSlide").style.width = "0";
}


//document.getElementById("a-b").addEventListener("click" , validate);
	

 
 
function validate(e) {  

	e.preventDefault();{

        var name = document.getElementById("name"); 
		var email = document.getElementById("email");
		var message = document.getElementById("message");
		var checkrem = document.getElementById("checkrem");
		var dataname = document.getElementById("dataname");
		var datamail= document.getElementById("datamail");
		var datamessage = document.getElementById("datamessage");
		
		console.log("Name:",name.value);
		console.log("E-mail:",email.value);
		console.log("Message:",message.value);
		document.getElementById("dataname").innerHTML= name.value;
		document.getElementById("datamail").innerHTML= email.value;
		document.getElementById("datamessage").innerHTML = message.value;
       
	   if (name.value.length <= 0) {  
            alert("Name is required");  
            name.focus();  
            return false;  
        }
		if (email.value.length <= 0) {    
                alert("Email Id is required");    
                email.focus();    
                return false;    
            }   
		if(message.value.length <= 20){
			alert("Please Write Minimum 20 words about your message");
			message.focus();
			return false;
		}
		if(checkrem.checked){
			
		}else{
			alert("Please accept our Term of Service");
			checkrem.focus();
			return false;
		}
	}
}			







